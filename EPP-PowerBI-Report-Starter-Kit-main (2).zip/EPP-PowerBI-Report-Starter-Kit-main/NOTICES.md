# EPP PowerBI Report Starter Kit

This product includes software developed at the [Ed-Fi
Alliance](https://www.ed-fi.org).

Copyright (c) 2020 Ed-Fi Alliance, LLC and contributors.

This software distribution includes or contains external references to several
open source packages that are attributed below in this notice. Where required,
copies of the license agreement are provided in separate files in the Licenses
subdirectory. Unless noted below, all open source software is distributed in its
original form without modification.
